package recursao;

public class TestarMetodosRecursivos {
	public static void main(String[] args) {
		//int[] array = {1,2,3,4,5};
		MetodosRecursivos mr = new MetodosRecursivos();
		//System.out.println(mr.calcularSomaArray(array, 4));

		System.out.println(mr.calcularFibonacci(5));
	}
}
